

overall_background = "#fafafa"
button_background_color = "#ececec"
disabled_button_color = "#D4D4D"
tab_name_color = "#5a6268"
text_area_background = "#f5f5f5"
text_area_border = "#ececec"

