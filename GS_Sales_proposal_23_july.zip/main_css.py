import streamlit as st

def add_professional_css():
    """Add professional CSS styling - BLACK AND WHITE THEME"""
    st.markdown("""
    <style>
    /* Global styling */
    .main .block-container {
        padding-top: 1rem;
        padding-bottom: 1rem;
        max-width: 1200px;
        background:#ffffff;
    }
    
    /* Header styling - more compact */
    .main-header {
        background: linear-gradient(135deg, #333333 0%, #ffffff 100%);
        padding: 1rem;
        border-radius: 6px;
        margin-bottom: 1rem;
        text-align: center;
        color: #599cd4;
    }
    
    .main-header h1 {
        margin: 0;
        font-size: 1.6rem;
        font-weight: 600;
        color: #599cd4;
    }
    
    .main-header p {
        margin: 0.2rem 0 0 0;
        font-size: 0.9rem;
        opacity: 0.9;
        color: #cccccc;
    }
    
    /* Section styling - much more compact */
    .form-section {
        padding: 0.8rem 1rem;
        border-radius: 6px;
        box-shadow: 0 1px 4px rgba(255,255,255,0.1);
        margin-bottom: 0.8rem;
        border: 1px solid #ececec;
        background: #ffffff;
    }
    
    .section-title {
        color: #599cd4;
        font-size: 1rem;
        font-weight: 600;
        margin-bottom: 0.6rem;
        padding-bottom: 0.2rem;
        border-bottom: 2px solid #666666;
    }
    
    /* Form field styling - MADE SMALLER */
    .field-label {
        color: #cccccc;
        font-weight: 600;
        margin-bottom: 0.2rem;
        display: block;
        font-size: 0.85rem;
    }
    
    .required-asterisk {
        color: #599cd4;
        font-weight: bold;
        margin-left: 3px;
    }
    
    /* Input field improvements - MUCH MORE COMPACT */
    .stTextInput > div > div > input {
        border-radius: 4px;
        border: 1px solid #ececec;
        padding: 0.4rem 0.6rem;
        font-size: 0.85rem;
        transition: all 0.3s ease;
        background: #ffffff;
        color: #599cd4;
        height: 2rem;
    }
    
    .stTextInput > div > div > input:focus {
        border-color: #999999;
        box-shadow: 0 0 0 2px rgba(89, 156, 212, 0.3);
        background: #ffffff;
    }
    
    .stSelectbox > div > div > div {
        border-radius: 4px;
        border: 1px solid #ececec;
        transition: all 0.3s ease;
        background: #ffffff;
        color: #599cd4;
        min-height: 2rem;
    }
    
    .stSelectbox > div > div > div:focus-within {
        border-color: #999999;
        box-shadow: 0 0 0 2px rgba(89, 156, 212, 0.3);
        background: #ffffff;
    }
    
    .stTextArea > div > div > textarea {
        border-radius: 4px;
        border: 1px solid #ececec;
        padding: 0.4rem 0.6rem;
        font-size: 0.85rem;
        transition: all 0.3s ease;
        background: #ffffff;
        color: #599cd4;
    }
    
    .stTextArea > div > div > textarea:focus {
        border-color: #999999;
        box-shadow: 0 0 0 2px rgba(89, 156, 212, 0.3);
        background: #ffffff;
    }
    
    /* File uploader styling - more compact */
    .stFileUploader > div {
        border: 2px dashed #ececec;
        border-radius: 6px;
        padding: 0.8rem;
        text-align: center;
        transition: all 0.3s ease;
        background: #ffffff;
        color: #cccccc;
    }
    
    .stFileUploader > div:hover {
        border-color:  #ececec;
        background: #ffffff;
    }
    
    /* Link button styling - more compact */
    .external-link-btn {
        background: #666666;
        border: none;
        padding: 0.3rem 0.6rem;
        border-radius: 4px;
        text-decoration: none;
        font-weight: 600;
        transition: all 0.3s ease;
        display: inline-block;
        font-size: 0.75rem;
        color: #599cd4;
        height: 2rem;
        line-height: 1.6rem;
    }
    
    .external-link-btn:hover {
        background: #ffffff;
        transform: translateY(-1px);
        text-decoration: none;
        color: #599cd4;
    }
    
    /* Validation styling - more compact */
    .validation-success {
        color: #599cd4;
        font-size: 0.75rem;
        margin-top: 0.2rem;
        display: flex;
        align-items: center;
        gap: 5px;
    }
    
    .validation-error {
        color: #cccccc;
        font-size: 0.75rem;
        margin-top: 0.2rem;
        display: flex;
        align-items: center;
        gap: 5px;
    }
    
    /* Progress styling - more compact */
    .progress-container {
        padding: 0.8rem;
        border-radius: 6px;
        box-shadow: 0 1px 4px rgba(255,255,255,0.1);
        border: 1px solid #ececec;
        background: #ffffff;
        color: #599cd4;
    }
    
    /* Info styling - more compact */
    .info-container {
        background: #ffffff;
        border-left: 4px solid #666666;
        padding: 0.6rem;
        border-radius: 0 4px 4px 0;
        margin: 0.3rem 0;
        font-size: 0.85rem;
        color: #cccccc;
    }
    
    /* Reduce spacing between elements - CRITICAL FOR COMPACTNESS */
    .element-container {
        margin-bottom: 0.3rem !important;
    }
    
    .stColumns > div {
        padding: 0 0.3rem;
    }
    
    /* Compact sidebar */
    .css-1d391kg {
        padding-top: 0.8rem;
        background:#ffffff;
        color: #599cd4;
    }
    
    /* General dark theme colors */
    .stApp {
        background:#ffffff;
        color: #599cd4;
    }
    
    /* Streamlit element colors */
    .stMarkdown {
        color: #599cd4;
    }
    
    /* Hide default streamlit styling */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {visibility: hidden;}
    
    /* COMPACT column-container for suggestions */
    .column-container {
        margin: 0.5rem 0;
    }
    
    .left-column, .right-column {
        padding: 0.6rem;
        border-radius: 6px;
        box-shadow: 0 1px 4px rgba(255,255,255,0.1);
        border: 1px solid #ececec;
        background: #ffffff;
        height: 100%;
    }
    
    .column-header {
        color: #599cd4;
        font-size: 0.95rem;
        font-weight: 600;
        margin-bottom: 0.6rem;
        padding-bottom: 0.2rem;
        border-bottom: 2px solid #666666;
                height:6rem!important;
    }
    
    .column-content {
        height: calc(100% - 2rem);
    }
    
    .suggestion-container {
        background: #ffffff;
        border: 1px solid #ececec;
        padding: 0.5rem;
        margin: 0.3rem 0;
        border-radius: 4px;
        transition: all 0.3s ease;
    }
    
    .suggestion-container:hover {
        background: #ffffff;
        border-color:  #ececec;
    }
    
    .suggestion-title {
        font-size: 0.8rem;
        font-weight: 500;
        color: #599cd4;
    }
    
    .suggestion-added {
        background: #ffffff !important;
        border-color:  #ececec !important;
    }
    
    .warning-container, .info-container {
        padding: 0.6rem;
        border-radius: 4px;
        margin: 0.3rem 0;
        font-size: 0.85rem;
    }
    
    .warning-container {
        background: #ffffff;
        border: 1px solid #ececec;
        color: #cccccc;
    }
    
    .action-buttons {
        margin-top: 0.8rem;
        padding-top: 0.6rem;
        border-top: 1px solid #666666;
    }
    </style>
    """, unsafe_allow_html=True)


app_css = """
<style>
/* Import Google Fonts */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600&display=swap');

/* Global styles - 75% screen width with equal margins */
.stApp {
    background:#ffffff;
    font-family: 'Inter', sans-serif;
    min-height: 100vh;
}

/* Container with 75% width and centered positioning */
.block-container {
    padding: 1rem 0 2rem 0;
    max-width: 75% !important;
    width: 75% !important;
    margin: 0 auto !important;
    left: 12.5% !important;
    right: 12.5% !important;
}

/* Main container - 75% width centered */
.main-container {
    width: 100%;
    min-height: 100vh;
    margin: 0 auto;
    padding: 0 2rem;
}

/* Header styling - Full width within container */
.main-header {
    width: 100%;
    padding: 3rem 0;
    margin-bottom: 2rem;
    background: #ffffff;
    border: 1px solid #ececec;
    border-radius: 20px;
    box-shadow: 0 8px 32px rgba(255, 255, 255, 0.1);
    position: relative;
    overflow: hidden;
}

.main-header h1 {
    color: #599cd4;
    font-size: 4rem;
    font-weight: 800;
    margin: 0;
    text-align: center;
    text-shadow: 2px 2px 8px rgba(255, 255, 255, 0.1);
    letter-spacing: -0.02em;
}

/* Creative tab separators */
.tab-nav-container {
    width: 100%;
    position: relative;
    margin-bottom: 2rem;

}

.tab-separator-line {
    width: 100%;
    height: 1px;
    background: linear-gradient(90deg, 
        transparent 0%, 
        #666666 25%, 
        #999999 50%, 
        #666666 75%, 
        transparent 100%);
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    z-index: 1;
}

.tab-separator {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 3rem;
    position: relative;
}

.separator-diamond {
    width: 8px;
    height: 8px;
    background: #599cd4;
    transform: rotate(45deg);
    border-radius: 2px;
    box-shadow: 0 0 15px rgba(89, 156, 212, 0.3);
    animation: pulse-diamond 2s ease-in-out infinite;
    z-index: 2;
}

.separator-line {
    width: 2px;
    height: 30px;
    background: linear-gradient(180deg, 
        #666666 0%, 
        #999999 50%, 
        #666666 100%);
    margin: 4px 0;
    border-radius: 1px;
    box-shadow: 0 0 10px rgba(255, 255, 255, 0.2);
    z-index: 2;
}

@keyframes pulse-diamond {
    0%, 100% {
        transform: rotate(45deg) scale(1);
        box-shadow: 0 0 15px rgba(89, 156, 212, 0.3);
    }
    50% {
        transform: rotate(45deg) scale(1.2);
        box-shadow: 0 0 25px rgba(89, 156, 212, 0.5);
    }
}

/* Tab styling - Improved modern design */
.stButton > button {
    background: #2a2a2a !important;
    color: #599cd4 !important;
    border: 1px solid #ececec !important;
    font-weight: 600 !important;
    font-size: 1.1rem !important;
    text-transform: uppercase !important;
    letter-spacing: 1px !important;
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1) !important;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3) !important;
    height: 3rem !important;
    border-radius: 15px !important;
    position: relative !important;
    overflow: hidden !important;
}

.stButton > button::before {
    content: '' !important;
    position: absolute !important;
    top: 0 !important;
    left: -100% !important;
    width: 100% !important;
    height: 100% !important;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent) !important;
    transition: left 0.5s ease !important;
}

.stButton > button:hover::before {
    left: 100% !important;
}

.stButton > button:hover {
    transform: translateY(-3px) scale(1.02) !important;
    box-shadow: 0 8px 30px rgba(255, 255, 255, 0.1) !important;
    background: #3a3a3a !important;
    border-color: #999999 !important;
}

/* Active tab styling */
.stButton > button:focus,
.stButton > button:active {
    background: #599cd4 !important;
    color:#ffffff !important;
    border-color: #cccccc !important;
    transform: translateY(-2px) scale(1.03) !important;
    box-shadow: 0 10px 40px rgba(89, 156, 212, 0.2) !important;
    font-weight: 700 !important;
}

/* Content area - Full width within the 75% container */
.content-area {
    background: #ffffff;
    padding: 3rem;
    border-radius: 20px;
    margin-bottom: 2rem;
    border: 1px solid #ececec;
    min-height: 70vh;
    width: 100%;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
    position: relative;
    overflow: hidden;
}

.content-area h2 {
    color: #599cd4;
    font-size: 2.5rem;
    margin-bottom: 1.5rem;
    font-weight: 700;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
}

.content-area h3 {
    color: #cccccc;
    font-size: 1.5rem;
    margin-bottom: 1.2rem;
    font-weight: 600;
}

.content-area p {
    color: #999999;
    font-size: 1.2rem;
    line-height: 1.8;
    margin-bottom: 1.5rem;
}

/* Full-width grid layouts for content within the 75% container */
.full-width-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
    width: 100%;
    margin: 2rem 0;
}

.grid-item {
    background: #2a2a2a;
    padding: 2rem;
    border-radius: 15px;
    border: 1px solid #ececec;
    transition: all 0.3s ease;
}

.grid-item:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(255, 255, 255, 0.1);
    background: #333333;
}

/* Footer styling - Full width within container */
.footer {
    background: #ffffff;
    padding: 2rem;
    border-radius: 20px;
    text-align: center;
    margin-top: 3rem;
    border: 1px solid #ececec;
    width: 100%;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
}

/* Footer button styling - Enhanced */
.footer .stButton > button {
    height: 4rem !important;
    font-weight: 700 !important;
    border-radius: 15px !important;
    border: none !important;
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1) !important;
    font-size: 1.1rem !important;
    text-transform: uppercase !important;
    letter-spacing: 1px !important;
    position: relative !important;
    overflow: hidden !important;
}

.footer .stButton > button::before {
    content: '' !important;
    position: absolute !important;
    top: 0 !important;
    left: -100% !important;
    width: 100% !important;
    height: 100% !important;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent) !important;
    transition: left 0.6s ease !important;
}

.footer .stButton > button:hover::before {
    left: 100% !important;
}

/* Refresh Button */
.footer div[data-testid="column"]:nth-child(1) .stButton > button {
    background: #666666 !important;
    color: #599cd4 !important;
    box-shadow: 0 6px 20px rgba(255, 255, 255, 0.1) !important;
}

.footer div[data-testid="column"]:nth-child(1) .stButton > button:hover {
    transform: translateY(-3px) scale(1.05) !important;
    box-shadow: 0 10px 30px rgba(255, 255, 255, 0.2) !important;
    background: #333333 !important;
}

/* Generate Presentation Button */
.footer div[data-testid="column"]:nth-child(2) .stButton > button {
    background: #599cd4 !important;
    color:#ffffff !important;
    box-shadow: 0 6px 20px rgba(89, 156, 212, 0.2) !important;
}

.footer div[data-testid="column"]:nth-child(2) .stButton > button:hover {
    transform: translateY(-3px) scale(1.05) !important;
    box-shadow: 0 10px 30px rgba(89, 156, 212, 0.3) !important;
    background: #4a8bc2 !important;
}

/* Input styling - Modern glassmorphism */
.stSelectbox > div > div > div,
.stTextInput > div > div > input,
.stTextArea > div > div > textarea {
    background: #2a2a2a !important;
    color: #599cd4 !important;
    border: 1px solid #ececec !important;
    border-radius: 10px !important;
    font-size: 1.1rem !important;
    transition: all 0.3s ease !important;
}

.stSelectbox > div > div > div:focus,
.stTextInput > div > div > input:focus,
.stTextArea > div > div > textarea:focus {
    border-color: #999999 !important;
    box-shadow: 0 0 20px rgba(89, 156, 212, 0.1) !important;
    background: #333333 !important;
}

/* File uploader styling */
.stFileUploader > div {
    background: #2a2a2a !important;
    border: 2px dashed #666666 !important;
    border-radius: 15px !important;
    padding: 2rem !important;
    transition: all 0.3s ease !important;
}

.stFileUploader > div:hover {
    border-color: #999999 !important;
    background: #333333 !important;
}

.stFileUploader label, .stFileUploader p, .stFileUploader svg {
    color: #599cd4 !important;
    fill: #599cd4 !important;
}

/* Sidebar removal */
.css-1d391kg {
    display: none !important;
}

/* Hide Streamlit elements */
#MainMenu {visibility: hidden;}
footer {visibility: hidden;}
header {visibility: hidden;}
.stToolbar {visibility: hidden;}

/* Custom scrollbar */
::-webkit-scrollbar {
    width: 8px;
}

::-webkit-scrollbar-track {
    background: #2a2a2a;
    border-radius: 10px;
}

::-webkit-scrollbar-thumb {
    background: #666666;
    border-radius: 10px;
}

::-webkit-scrollbar-thumb:hover {
    background: #999999;
}

/* Responsive design */
@media (max-width: 768px) {
    .block-container {
        max-width: 95% !important;
        width: 95% !important;
        left: 2.5% !important;
        right: 2.5% !important;
    }
    
    .main-header h1 {
        font-size: 2.5rem;
    }
    
    .content-area {
        padding: 1.5rem;
    }
    
    .stButton > button {
        height: 3rem !important;
        font-size: 0.9rem !important;
    }
}

/* Loading animations */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.content-area {
    animation: fadeInUp 0.6s ease-out;
}

/* Enhanced metrics and cards */
.metric-card {
    background: #2a2a2a;
    border: 1px solid #ececec;
    border-radius: 15px;
    padding: 2rem;
    text-align: center;
    transition: all 0.3s ease;
}

.metric-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(255, 255, 255, 0.1);
    background: #333333;
}

.metric-value {
    font-size: 2.5rem;
    font-weight: 800;
    color: #599cd4;
    margin-bottom: 0.5rem;
}

.metric-label {
    color: #999999;
    font-size: 1.1rem;
    font-weight: 500;
}
/* COMPREHENSIVE FOCUS COLOR FIX - CYAN ONLY */

/* Remove Streamlit's default red focus styling */
textarea,
input,
select,
[contenteditable] {
    border-color: transparent !important;
}

/* Apply cyan focus to all input types with highest specificity */
.stTextInput > div > div > input:focus,
.stTextArea > div > div > textarea:focus,
.stNumberInput > div > div > input:focus,
.stDateInput > div > div > input:focus,
.stTimeInput > div > div > input:focus,
.stSelectbox > div > div > div:focus,
.stMultiSelect > div > div > div:focus,
textarea:focus,
input:focus,
[data-testid="stTextArea"] textarea:focus,
[data-testid="stTextInput"] input:focus,
[data-testid="stNumberInput"] input:focus,
[data-testid="stDateInput"] input:focus,
[data-testid="stTimeInput"] input:focus {
    border: 2px solid #42f5e9 !important;
    box-shadow: 0 0 0 2px rgba(66, 245, 233, 0.2) !important;
    outline: none !important;
    background-color: #f5f5f5 !important;
    color: #2a2a2a !important;
}

/* Remove any conflicting focus-visible styles */
textarea:focus-visible,
input:focus-visible,
select:focus-visible {
    border: 2px solid #42f5e9 !important;
    box-shadow: 0 0 0 2px rgba(66, 245, 233, 0.2) !important;
    outline: none !important;
}

/* Override any Streamlit default focus ring */
*:focus {
    box-shadow: 0 0 0 2px rgba(66, 245, 233, 0.2) !important;
    outline: none !important;
}

/* Specific override for text areas and inputs */
div[data-baseweb="textarea"] textarea:focus,
div[data-baseweb="input"] input:focus {
    border: 2px solid #42f5e9 !important;
    box-shadow: 0 0 0 2px rgba(66, 245, 233, 0.2) !important;
}
</style>
"""
sticky_header_css = """
<style>
/* Make the app container handle overflow properly */
.stApp {
    height: 20vh;
}

/* Create sticky header - this will freeze the header */
.sticky-header {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 1000;
    background-color: white;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

/* Header content container with 75% width */
.header-content {
    width: 75%;
    max-width: 75%;
    margin-left: auto;
    margin-right: auto;
    background-color: white;
}

/* Main scrollable content area */
.scrollable-content {
    margin-top: 80px; /* Reduced from 140px to 80px */
    height: calc(100vh - 80px);
    overflow-y: auto;
    background-color: #fafafa;
    width: 75%;
    max-width: 75%;
    margin-left: auto;
    margin-right: auto;
    padding: 20px;
}

/* Override streamlit's default container behavior */
[data-testid="block-container"] {
    background-color: transparent !important;
    width: 100% !important;
    max-width: 100% !important;
    margin: 0 !important;
    padding: 0 !important;
}
</style>
"""

button_css = """
<style>
/* Primary buttons - 48px height */
div.stButton > button[kind="primary"] {
    height: 48px !important;
    min-height: 48px !important;
    line-height: 1.2 !important;
    padding: 0 16px !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    color : white !important;
    
}

/* Alternative selector in case the above doesn't work */
button[data-testid="baseButton-primary"] {
    height: 48px !important;
    min-height: 48px !important;
    line-height: 1.2 !important;
    padding: 0 16px !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    color : white !important;
}

/* For buttons with specific styling classes */
.stButton button[kind="primary"],
.stButton button[type="primary"] {
    height: 48px !important;
    min-height: 48px !important;
    line-height: 1.2 !important;
    padding: 0 16px !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    color : white !important;
}

/* Ensure text is centered vertically */
div.stButton > button[kind="primary"] p {
    margin: 0 !important;
    line-height: 1.2 !important;
}
</style>
"""
css_styles = """
        div[data-testid="stBlock"] {
            position: fixed !important;
            top: 20% !important;
            left: 50% !important;
            transform: translateX(-50%) !important;
            z-index: 9999 !important;
            background: black !important;
            border: 1px solid #ddd !important;
            border-radius: 12px !important;
            padding: 30px !important;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15) !important;
            width: 450px !important;
            max-width: 90vw !important;
            border-top: 4px solid #f56565 !important;
        }
        div[data-testid="stBlock"]:before {
            content: '' !important;
            position: fixed !important;
            top: 0 !important;
            left: 0 !important;
            width: 100vw !important;
            height: 180vh !important;
            background: rgba(0, 0, 0, 0.4) !important;
            z-index: -1 !important;
        }
        """
content_area_css = """
<style>
/* Primary targeting for block container - 75% width grey background */
[data-testid="block-container"] {
    background-color: #fafafa !important;
    width: 75% !important;
    max-width: 75% !important;
    margin-left: auto !important;
    margin-right: auto !important;
}

/* Alternative targeting for older Streamlit versions */
.block-container {
    background-color: #fafafa !important;
    width: 75% !important;
    max-width: 75% !important;
    margin-left: auto !important;
    margin-right: auto !important;
}

/* Target the element that contains your tab content */
.stApp .main .block-container {
    background-color: #fafafa !important;
    width: 75% !important;
    max-width: 75% !important;
    margin-left: auto !important;
    margin-right: auto !important;
}
</style>
"""
button_css_2 = """
<style>
.sticky-tabs {
    position: sticky;
    top: 120px; /* Adjust based on your header height */
    z-index: 999;
    background-color: white;
    padding: 10px 0;
    border-bottom: 1px solid #e0e0e0;
    margin-bottom: 20px;
}

/* Force override all button styling */
button[kind="secondary"] {
    height: 48px !important;
    border: 2.2px solid #ececec !important;
    border-radius: 4px !important;
    margin-top: -5px !important;  /* Move button up */
    transform: translateY(-3px) !important;  /* Additional upward adjustment */
    background-color: #d3d3d3 !important;  
    color: black !important;  /* black text */
}
    
button[kind="secondary"]:hover {
    border: 2.2px solid #ececec !important;
    transform: translateY(-3px) !important;  /* Keep position on hover */
    background-color: #d3d3d3 !important;  /* Slightly lighter on hover */
    color: black !important;  /* Keep black text on hover */
}
    
button[kind="secondary"]:focus {
    border: 2.2px solid #ececec !important;
    outline: 2px solid #ececec !important;
    transform: translateY(-3px) !important;  /* Keep position on focus */
    background-color: #d3d3d3 !important;  /* Keep dark background on focus */
    color: black !important;  /* Keep black text on focus */
}
    
/* Try targeting by data attributes */
[data-testid] button {
    border: 2.2px solid #ececec !important;
    height: 48px !important;
    margin-top: -5px !important;  /* Move button up */
    transform: translateY(-2.5px) !important;  /* Additional upward adjustment */
    background-color: #d3d3d3 !important;  /* Dark greyish background */
    color: black !important;  /* black text */
}

/* Additional targeting for button text specifically */
button[kind="secondary"] p,
button[kind="secondary"] span,
button[kind="secondary"] div {
    color: black !important;
}

[data-testid] button p,
[data-testid] button span,
[data-testid] button div {
    color: black !important;
}
</style>
"""

header_css = """
<style>
.sticky-tabs {
    position: sticky;
    top: 120px; /* Adjust based on your header height */
    z-index: 999;
    background-color: white;
    padding: 10px 0;
    border-bottom: 1px solid #e0e0e0;
    margin-bottom: 20px;
}

/* Force override all button styling */
button[kind="secondary"] {
    height: 48px !important;
    border: 2.2px solid #ececec !important;
    border-radius: 4px !important;
    margin-top: -5px !important;  /* Move button up */
    transform: translateY(-3px) !important;  /* Additional upward adjustment */
    background-color: #d3d3d3 !important;  
    color: black !important;  /* black text */
}
    
button[kind="secondary"]:hover {
    border: 2.2px solid #ececec !important;
    transform: translateY(-3px) !important;  /* Keep position on hover */
    background-color: #d3d3d3 !important;  /* Slightly lighter on hover */
    color: black !important;  /* Keep black text on hover */
}
    
button[kind="secondary"]:focus {
    border: 2.2px solid #ececec !important;
    outline: 2px solid #ececec !important;
    transform: translateY(-3px) !important;  /* Keep position on focus */
    background-color: #d3d3d3 !important;  /* Keep dark background on focus */
    color: black !important;  /* Keep black text on focus */
}
    
/* Try targeting by data attributes */
[data-testid] button {
    border: 2.2px solid #ececec !important;
    height: 48px !important;
    margin-top: -5px !important;  /* Move button up */
    transform: translateY(-2.5px) !important;  /* Additional upward adjustment */
    background-color: #d3d3d3 !important;  /* Dark greyish background */
    color: black !important;  /* black text */
}

/* Additional targeting for button text specifically */
button[kind="secondary"] p,
button[kind="secondary"] span,
button[kind="secondary"] div {
    color: black !important;
}

[data-testid] button p,
[data-testid] button span,
[data-testid] button div {
    color: black !important;
}
</style>
"""