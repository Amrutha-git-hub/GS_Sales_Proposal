f_string = '''Title: Title of the sales proposal
Text: Accelerating Revenue Growth for Ashok Leyland: A GrowthSutra Strategic Partnership

Title: Executive Summary
Text: GrowthSutra proposes a phased approach to significantly enhance Ashok Leyland's revenue generation capabilities.  Our expert team will conduct a thorough assessment of your current sales processes, design a robust revenue engine, develop a detailed implementation plan, and ensure seamless knowledge transfer. This collaborative partnership leverages our Fortune 500-caliber expertise to deliver measurable results and drive sustainable growth, particularly within your Alternate Fuel vehicle segment.  The total project cost is $45,000, spread across five distinct phases.

Title: Introduction
Text: Ashok Leyland operates in a dynamic and competitive market.  To maintain a leading position and capitalize on emerging opportunities, particularly in the Alternate Fuel vehicle sector, a strategic overhaul of your revenue generation processes is crucial. GrowthSutra offers the specialized expertise and proven methodologies to achieve this, accelerating your brand and revenue growth.

Title: About GrowthSutra
Text: GrowthSutra is a leading strategic growth consultancy specializing in accelerating brand and revenue growth for businesses of all sizes. Our team comprises seasoned executives with 20+ years of experience launching and scaling disruptive brands across diverse sectors. We combine proven data-driven frameworks with rigorous project governance to deliver measurable results quickly. We are confident in our ability to help Ashok Leyland achieve its revenue goals.

Title: Understanding Your Needs
Text: We understand Ashok Leyland requires a data-driven approach to optimize sales processes, identify high-growth market segments (including Alternate Fuels), and develop a sustainable revenue engine.  This includes defining clear value propositions, creating a robust go-to-market strategy, and implementing a phased rollout plan with measurable KPIs.  Our understanding is based on [mention any preliminary research or discussions held]. We aim to address these needs through a collaborative and iterative process.

Title: Proposed Solution (Revenue Architect & XPRT Co-Pilots)
Text: Our proposed solution, tailored for Ashok Leyland's specific needs, involves a comprehensive five-phase engagement.  We will act as your revenue architects, providing strategic direction and tactical execution, and as your XPRT co-pilots, working collaboratively with your internal teams for seamless integration and knowledge transfer. This ensures a sustainable, long-term impact on your revenue generation capabilities.

Title: Scope of Work / Project Breakdown
Text: This project is divided into five distinct phases:

**Phase 1: Discovery & Assessment (5 days, $7,500)**
* Conduct thorough interviews with key stakeholders across sales, marketing, and product development.
* Analyze existing sales data to identify strengths, weaknesses, opportunities, and threats.
* Conduct comprehensive market research, including competitor analysis, to identify key trends and opportunities.
* Develop a detailed understanding of Ashok Leyland's current sales processes, identifying bottlenecks and areas for improvement.
* Document key findings and present initial recommendations.

**Phase 2: Revenue Engine Design & Strategy (10 days, $15,000)**
* Define target customer segments, including a focused approach to Alternate Fuel vehicle markets.
* Develop compelling and tailored value propositions for each identified segment.
* Design a comprehensive revenue engine blueprint, outlining key processes, systems, and resources.
* Create a detailed go-to-market strategy for each segment, including marketing and sales plans.
* Develop initial sales training materials and enablement resources.

**Phase 3: Implementation Planning & Roadmap (7 days, $10,500)**
* Develop a detailed implementation plan with clear milestones, timelines, and responsibilities.
* Define key performance indicators (KPIs) to track progress and measure success.
* Outline resource allocation, including personnel, budget, and technology.
* Recommend a suitable technology stack to support the new revenue engine.
* Develop a phased rollout approach to minimize disruption and maximize adoption.

**Phase 4: Presentation & Alignment (3 days, $4,500)**
* Present the revenue engine design, implementation plan, and projected impact to Ashok Leyland stakeholders.
* Facilitate a discussion to address any concerns and secure buy-in for the next phase.
* Address any stakeholder feedback and refine the plan accordingly.
* Secure formal sign-off on the proposed implementation plan.

**Phase 5: Documentation & Handoff (5 days, $7,500)**
* Create comprehensive documentation of all deliverables, including the revenue engine design, implementation plan, data analysis, and recommendations for future optimization.
* Conduct thorough knowledge transfer sessions with the Ashok Leyland team.
* Ensure a smooth transition of responsibilities and ongoing support for successful implementation.
* Provide post-project support for clarifying any remaining questions.

Title: Timeline & Milestones
Text: The project is anticipated to be completed within 30 days, with key milestones at the end of each phase. A detailed project schedule will be provided upon project kickoff.

Title: Pricing & Payment Terms
Text: The total project cost is $45,000. Payment terms are 30% upon contract signing, 30% upon completion of Phase 2, and 40% upon final delivery and acceptance of all deliverables in Phase 5.  A detailed breakdown of costs per phase is provided in the Scope of Work section.

Title: Next Steps
Text: We propose a brief introductory call to discuss your specific requirements and answer any questions. Following this call, we can finalize the contract and commence the project.

Title: Appendix (Optional)
Text: 

Title: Who We Are
Text: GrowthSutra is a team of experienced strategic growth consultants dedicated to helping businesses like Ashok Leyland achieve significant revenue growth. We bring a wealth of experience and a results-oriented approach to every engagement.

Title: What We Do
Text: We provide comprehensive strategic growth consulting services, including market research, revenue engine design, go-to-market strategy development, implementation planning, and ongoing support.  Our goal is to empower our clients to achieve sustainable, long-term growth.
'''